package dao;

import java.sql.Date;

public class Transaction {
	 private int transactionId; // Use camelCase for variable names
	    private String bankAccount;
	    private String transactionType; // Deposit or Withdrawal
	    private double amount; // Changed from balance to amount for clarity
	    private Date transactionDate; // Changed from transaction_date to transactionDate

	    // Getters and Setters
	    public int getTransactionId() {
	        return transactionId;
	    }

	    public void setTransactionId(int transactionId) {
	        this.transactionId = transactionId;
	    }

	    public String getBankAccount() {
	        return bankAccount;
	    }

	    public void setBankAccount(String bankAccount) {
	        this.bankAccount = bankAccount;
	    }

	    public String getTransactionType() {
	        return transactionType;
	    }

	    public void setTransactionType(String transactionType) {
	        this.transactionType = transactionType;
	    }

	    public double getAmount() {
	        return amount;
	    }

	    public void setAmount(double amount) {
	        this.amount = amount;
	    }

	    public Date getTransactionDate() {
	        return transactionDate;
	    }

	    public void setTransactionDate(Date transactionDate) {
	        this.transactionDate = transactionDate;
	    }
	}

